import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * 
 */

/**
 * @author zhanglei01
 * @param <Item>
 */
public class RandomizedQueue<Item> implements Iterable<Item> {

    private Item[] itemArray;
    private int size;
    private int N;

    /**
     * 
     */
    public RandomizedQueue() {
        size = 0;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public void enqueue(Item item) {
        if (item == null) {
            throw new NullPointerException();
        }

        // new a item[1] when array is empty; increase array total length by 2
        // times when array is full
        if (isEmpty()) {
            N = 1;
            itemArray = (Item[]) new Object[N];
        } else if (N == size) {
            N = 2 * size;
            Item[] newItemArray = (Item[]) new Object[N];
            for (int i = 0; i < size; i++) {
                newItemArray[i] = itemArray[i];
            }
            itemArray = newItemArray;
        }

        itemArray[size++] = item;

    }

    public Item dequeue() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        int rIndex = StdRandom.uniform(size);
        Item oldItem = itemArray[rIndex];
        itemArray[rIndex] = itemArray[size - 1];
        itemArray[size - 1] = null;
        size--;

        if (size <= N / 4 && size > 1) {
            N /= 2;
            Item[] newItemArray = (Item[]) new Object[N];
            for (int i = 0; i < size; i++) {
                newItemArray[i] = itemArray[i];
            }
            itemArray = newItemArray;
        }

        return oldItem;
    }

    public Item sample() {
        if (isEmpty()) {
            throw new NoSuchElementException();
        }
        int rIndex = StdRandom.uniform(size);
        return itemArray[rIndex];
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        RandomizedQueue<Integer> rqueue = new RandomizedQueue<Integer>();
        rqueue.enqueue(1);
        rqueue.enqueue(1);
        rqueue.enqueue(3);
        rqueue.enqueue(2);
        System.out.println(rqueue.size());
        System.out.println(rqueue.dequeue());
        System.out.println(rqueue.dequeue());
        // System.out.println(rqueue.dequeue());
        // System.out.println(rqueue.dequeue());
        // System.out.println(rqueue.dequeue());
        //
        // rqueue.enqueue(1);
        // rqueue.enqueue(1);
        // rqueue.enqueue(3);
        // rqueue.enqueue(2);

//        for (Integer integer : rqueue) {
//            System.out.println(integer);
//        }
//
//        for (Integer integer : rqueue) {
//            System.out.println(integer);
//        }
    }

    @Override
    public Iterator<Item> iterator() {
        return new RandomizedQueueIterator();
    }

    private class RandomizedQueueIterator implements Iterator<Item> {

        private Item[] iteratorArray;
        private int iteratorSize;

        public RandomizedQueueIterator() {
            iteratorSize = size;
            iteratorArray = (Item[]) new Object[iteratorSize];
            for (int i = 0; i < iteratorSize; i++) {
                iteratorArray[i] = itemArray[i];
            }
            StdRandom.shuffle(iteratorArray);
        }

        @Override
        public boolean hasNext() {
            return iteratorSize != 0;
        }

        @Override
        public Item next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            return iteratorArray[--iteratorSize];
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

    }

}
